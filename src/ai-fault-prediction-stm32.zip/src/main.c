/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : AI-Based Machine Fault Prediction and Alert System
  *                   Using STM32 NUCLEO-L476RG + MPU6050 + NanoEdge AI
  ******************************************************************************
  * @attention
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* Private defines -----------------------------------------------------------*/
#define MPU6050_ADDR        0xD0    // MPU6050 I2C Address (0x68 << 1)
#define MPU6050_WHO_AM_I    0x75
#define MPU6050_PWR_MGMT_1  0x6B
#define MPU6050_SMPLRT_DIV  0x19
#define MPU6050_ACCEL_CONFIG 0x1C
#define MPU6050_ACCEL_XOUT_H 0x3B

#define DATA_INPUT_USER     256     // Buffer size for AI model input
#define AXIS_NUMBER         3       // X, Y, Z axes
#define SAMPLING_RATE_MS    10      // 10ms = 100Hz sampling

// Alert thresholds (for demonstration - these would come from AI model)
#define VIBRATION_WARNING   2.0f    // g-force threshold for warning
#define VIBRATION_CRITICAL  3.5f    // g-force threshold for critical

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
UART_HandleTypeDef huart2;

float mpu_buffer[AXIS_NUMBER * DATA_INPUT_USER] = {0};
float accel_data[3] = {0};  // Ax, Ay, Az

uint8_t fault_detected = 0;
uint8_t alert_level = 0;    // 0=Normal, 1=Warning, 2=Critical

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);

// MPU6050 Functions
uint8_t MPU6050_Init(void);
void MPU6050_Read_Accel(float *accel);
HAL_StatusTypeDef MPU6050_Write(uint8_t reg, uint8_t data);
HAL_StatusTypeDef MPU6050_Read(uint8_t reg, uint8_t *data, uint16_t len);

// Application Functions
void fill_mpu_buffer(void);
void Log_Data(void);
float calculate_rms(float *data, uint16_t len);
void check_fault_condition(void);
void trigger_alert(uint8_t level);
void send_data_to_nanoedge(void);

// UART printf support
int __io_putchar(int ch);

/* USER CODE END PFP */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
    /* MCU Configuration--------------------------------------------------------*/
    HAL_Init();
    SystemClock_Config();

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_USART2_UART_Init();
    MX_I2C1_Init();

    /* USER CODE BEGIN 2 */
    printf("\r\n=====================================\r\n");
    printf("AI-Based Fault Prediction System\r\n");
    printf("Board: NUCLEO-L476RG\r\n");
    printf("Sensor: MPU6050 Accelerometer\r\n");
    printf("=====================================\r\n\r\n");

    // Initialize MPU6050
    if (MPU6050_Init() != 0)
    {
        printf("ERROR: MPU6050 initialization failed!\r\n");
        Error_Handler();
    }
    printf("MPU6050 initialized successfully!\r\n");
    printf("Sampling Rate: 100Hz\r\n");
    printf("Buffer Size: %d samples x %d axes\r\n\r\n", DATA_INPUT_USER, AXIS_NUMBER);

    HAL_Delay(1000);
    /* USER CODE END 2 */

    /* Infinite loop */
    while (1)
    {
        /* MODE 1: Data Logging for NanoEdge AI Studio Training */
        // Uncomment below line to log data for AI training
        // send_data_to_nanoedge();

        /* MODE 2: Real-time Fault Detection */
        fill_mpu_buffer();
        check_fault_condition();
        Log_Data();

        HAL_Delay(500);  // 500ms between status updates
    }
}

/**
  * @brief  Initialize MPU6050 Accelerometer
  * @retval 0 if success, 1 if error
  */
uint8_t MPU6050_Init(void)
{
    uint8_t check = 0;

    // Check device ID
    MPU6050_Read(MPU6050_WHO_AM_I, &check, 1);
    if (check != 0x68)
    {
        printf("MPU6050 WHO_AM_I check failed! Got: 0x%02X\r\n", check);
        return 1;
    }

    // Wake up MPU6050 (clear sleep bit)
    MPU6050_Write(MPU6050_PWR_MGMT_1, 0x00);
    HAL_Delay(100);

    // Set sample rate divider (1kHz / (1 + 0) = 1kHz)
    MPU6050_Write(MPU6050_SMPLRT_DIV, 0x00);

    // Set accelerometer range to +/- 2g (0x00 = 2g, 0x08 = 4g, 0x10 = 8g, 0x18 = 16g)
    MPU6050_Write(MPU6050_ACCEL_CONFIG, 0x00);

    return 0;
}

/**
  * @brief  Read accelerometer data from MPU6050
  * @param  accel: pointer to float array [Ax, Ay, Az] in g-force
  */
void MPU6050_Read_Accel(float *accel)
{
    uint8_t buffer[6];
    int16_t raw_accel[3];

    // Read 6 bytes starting from ACCEL_XOUT_H
    MPU6050_Read(MPU6050_ACCEL_XOUT_H, buffer, 6);

    // Combine high and low bytes
    raw_accel[0] = (int16_t)(buffer[0] << 8 | buffer[1]);  // X
    raw_accel[1] = (int16_t)(buffer[2] << 8 | buffer[3]);  // Y
    raw_accel[2] = (int16_t)(buffer[4] << 8 | buffer[5]);  // Z

    // Convert to g-force (LSB sensitivity = 16384 LSB/g for +/- 2g range)
    accel[0] = (float)raw_accel[0] / 16384.0f;
    accel[1] = (float)raw_accel[1] / 16384.0f;
    accel[2] = (float)raw_accel[2] / 16384.0f;
}

/**
  * @brief  Write data to MPU6050 register
  */
HAL_StatusTypeDef MPU6050_Write(uint8_t reg, uint8_t data)
{
    HAL_StatusTypeDef status;
    uint8_t txData[2] = {reg, data};

    status = HAL_I2C_Master_Transmit(&hi2c1, MPU6050_ADDR, txData, 2, 100);
    return status;
}

/**
  * @brief  Read data from MPU6050 register
  */
HAL_StatusTypeDef MPU6050_Read(uint8_t reg, uint8_t *data, uint16_t len)
{
    HAL_StatusTypeDef status;

    status = HAL_I2C_Master_Transmit(&hi2c1, MPU6050_ADDR, &reg, 1, 100);
    if (status != HAL_OK) return status;

    status = HAL_I2C_Master_Receive(&hi2c1, MPU6050_ADDR, data, len, 100);
    return status;
}

/**
  * @brief  Fill buffer with MPU6050 data for AI processing
  */
void fill_mpu_buffer(void)
{
    for (int i = 0; i < DATA_INPUT_USER; i++)
    {
        MPU6050_Read_Accel(accel_data);

        mpu_buffer[AXIS_NUMBER * i]     = accel_data[0];  // Ax
        mpu_buffer[AXIS_NUMBER * i + 1] = accel_data[1];  // Ay
        mpu_buffer[AXIS_NUMBER * i + 2] = accel_data[2];  // Az

        HAL_Delay(SAMPLING_RATE_MS);  // 10ms delay = 100Hz
    }
}

/**
  * @brief  Calculate RMS value of vibration data
  */
float calculate_rms(float *data, uint16_t len)
{
    float sum = 0.0f;
    for (uint16_t i = 0; i < len; i++)
    {
        sum += (data[i] * data[i]);
    }
    return sqrtf(sum / len);
}

/**
  * @brief  Check fault conditions based on vibration levels
  *         In real deployment, this would use NanoEdge AI library
  */
void check_fault_condition(void)
{
    float rms_x = calculate_rms(&mpu_buffer[0], DATA_INPUT_USER);
    float rms_y = calculate_rms(&mpu_buffer[1], DATA_INPUT_USER);
    float rms_z = calculate_rms(&mpu_buffer[2], DATA_INPUT_USER);

    float max_rms = fmaxf(fmaxf(rms_x, rms_y), rms_z);

    if (max_rms > VIBRATION_CRITICAL)
    {
        alert_level = 2;  // CRITICAL
        trigger_alert(2);
    }
    else if (max_rms > VIBRATION_WARNING)
    {
        alert_level = 1;  // WARNING
        trigger_alert(1);
    }
    else
    {
        alert_level = 0;  // NORMAL
        trigger_alert(0);
    }
}

/**
  * @brief  Trigger alert based on fault level
  * @param  level: 0=Normal, 1=Warning, 2=Critical
  */
void trigger_alert(uint8_t level)
{
    switch (level)
    {
        case 0:  // Normal - Green LED steady
            HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);
            fault_detected = 0;
            break;

        case 1:  // Warning - LED blink slowly
            HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
            fault_detected = 1;
            printf("[WARNING] Elevated vibration detected!\r\n");
            break;

        case 2:  // Critical - LED blink fast + print alert
            HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
            fault_detected = 1;
            printf("[CRITICAL] High vibration detected! Potential fault!\r\n");
            break;
    }
}

/**
  * @brief  Log data to UART for debugging and monitoring
  */
void Log_Data(void)
{
    float rms_x = calculate_rms(&mpu_buffer[0], DATA_INPUT_USER);
    float rms_y = calculate_rms(&mpu_buffer[1], DATA_INPUT_USER);
    float rms_z = calculate_rms(&mpu_buffer[2], DATA_INPUT_USER);

    printf("----------------------------------------\r\n");
    printf("Status: %s\r\n",
           (alert_level == 0) ? "NORMAL" :
           (alert_level == 1) ? "WARNING" : "CRITICAL");
    printf("RMS X: %.4f g\tRMS Y: %.4f g\tRMS Z: %.4f g\r\n",
           rms_x, rms_y, rms_z);
    printf("----------------------------------------\r\n\r\n");
}

/**
  * @brief  Send formatted data to NanoEdge AI Studio for training
  *         Format: Ax,Ay,Az (one sample per line)
  */
void send_data_to_nanoedge(void)
{
    for (int i = 0; i < DATA_INPUT_USER; i++)
    {
        printf("%.4f,%.4f,%.4f\r\n",
               mpu_buffer[AXIS_NUMBER * i],
               mpu_buffer[AXIS_NUMBER * i + 1],
               mpu_buffer[AXIS_NUMBER * i + 2]);
    }
    printf("\r\n");  // Empty line between buffers
}

/* UART printf support -------------------------------------------------------*/
int __io_putchar(int ch)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)&ch, 1, HAL_MAX_DELAY);
    return ch;
}

/**
  * @brief System Clock Configuration
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM = 1;
    RCC_OscInitStruct.PLL.PLLN = 10;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
    RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
    RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief I2C1 Initialization Function
  */
static void MX_I2C1_Init(void)
{
    hi2c1.Instance = I2C1;
    hi2c1.Init.Timing = 0x10D19CE4;
    hi2c1.Init.OwnAddress1 = 0;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2 = 0;
    hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c1) != HAL_OK)
    {
        Error_Handler();
    }

    if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
    {
        Error_Handler();
    }

    if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief USART2 Initialization Function
  */
static void MX_USART2_UART_Init(void)
{
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 115200;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    if (HAL_UART_Init(&huart2) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

    GPIO_InitStruct.Pin = B1_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = LD2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);
}

/**
  * @brief  This function is executed in case of error occurrence.
  */
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
        HAL_Delay(100);
    }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    printf("Wrong parameters value: file %s on line %d\r\n", file, (int)line);
}
#endif
