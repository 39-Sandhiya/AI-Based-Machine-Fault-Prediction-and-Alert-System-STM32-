# 🔧 AI-Based Machine Fault Prediction & Alert System (STM32)

> Real-time vibration monitoring using STM32 NUCLEO-L476RG + MPU6050 accelerometer with AI-powered anomaly detection via NanoEdge AI Studio.

---

## 📋 Project Overview

| Parameter | Value |
|-----------|-------|
| **Board** | STM32 NUCLEO-L476RG |
| **Sensor** | MPU6050 3-Axis Accelerometer (I2C) |
| **IDE** | STM32CubeIDE |
| **AI Tool** | NanoEdge AI Studio (Anomaly Detection) |
| **Communication** | UART (USB Virtual COM, 115200 baud) |
| **Sampling Rate** | 100 Hz |
| **Buffer Size** | 256 samples × 3 axes |

---

## 🔌 Hardware Connections

```
MPU6050          NUCLEO-L476RG
-------          -------------
VCC  ──────────► 3.3V
GND  ──────────► GND
SCL  ──────────► PB8 (I2C1_SCL)
SDA  ──────────► PB9 (I2C1_SDA)
INT  ──────────► (Not used)
```

> **Note:** On NUCLEO-L476RG, I2C1 uses PB8 (SCL) and PB9 (SDA) by default.

---

## 🏗️ System Architecture

```
┌─────────────┐      I2C       ┌──────────────┐
│  MPU6050    │◄──────────────►│  STM32L476   │
│Accelerometer│                │   NUCLEO     │
└─────────────┘                └──────┬───────┘
                                      │
                                      │ UART (115200)
                                      ▼
                              ┌──────────────┐
                              │  PC/Laptop   │
                              │ NanoEdge AI  │
                              │   Studio     │
                              └──────────────┘
```

**Two Operating Modes:**
1. **Data Logging Mode** → Collect vibration data for AI training
2. **Inference Mode** → Real-time fault detection with alerts

---

## 📁 File Structure

```
ai-fault-prediction-stm32/
├── src/
│   ├── main.c          ← Main application code
│   └── main.h          ← Header file with pin definitions
├── docs/
│   └── (your report & PPT)
├── assets/
│   └── (your output images)
└── README.md           ← This file
```

---

## 🚀 How to Build & Run

### Step 1: STM32CubeIDE Setup
1. Open STM32CubeIDE
2. File → New → STM32 Project
3. Select **NUCLEO-L476RG** board
4. Configure:
   - **I2C1**: PB8 (SCL), PB9 (SDA)
   - **USART2**: PA2 (TX), PA3 (RX) — default for USB VCOM
   - **GPIO**: PA5 (LD2 LED)
5. Generate code

### Step 2: Add Project Files
1. Copy `main.c` and `main.h` from this repo to your project
2. Build (Ctrl+B)
3. Flash to board (Run → Debug)

### Step 3: Monitor Output
1. Open any Serial Terminal (PuTTY, Tera Term, or STM32CubeIDE built-in)
2. Set: **115200 baud, 8-N-1**
3. Press RESET on NUCLEO board

---

## 📊 Output Format

### Normal Operation (Status Logging)
```
========================================
AI-Based Fault Prediction System
Board: NUCLEO-L476RG
Sensor: MPU6050 Accelerometer
========================================

MPU6050 initialized successfully!
Sampling Rate: 100Hz
Buffer Size: 256 samples x 3 axes

----------------------------------------
Status: NORMAL
RMS X: 0.0234 g    RMS Y: 0.0156 g    RMS Z: 0.9876 g
----------------------------------------
```

### NanoEdge AI Data Format (for training)
```
0.0234,0.0156,0.9876
0.0241,0.0162,0.9881
0.0238,0.0159,0.9874
...
```

---

## 🎯 How the AI Works

```
Phase 1: DATA COLLECTION
    └── STM32 logs vibration data via UART
    └── NanoEdge AI Studio captures "Normal" and "Abnormal" signals

Phase 2: MODEL TRAINING
    └── NanoEdge AI trains anomaly detection model
    └── Generates optimized C library for STM32

Phase 3: EDGE INFERENCE
    └── Deploy AI library to STM32
    └── STM32 runs inference locally (no PC needed)
    └── Triggers alerts when anomaly detected
```

---

## 🚨 Alert System

| Level | Condition | LED Behavior | Action |
|-------|-----------|-------------|--------|
| **NORMAL** | RMS < 2.0g | Steady ON | None |
| **WARNING** | 2.0g ≤ RMS < 3.5g | Slow blink | Print warning |
| **CRITICAL** | RMS ≥ 3.5g | Fast blink | Print critical alert |

---

## 🛠️ Key Features

- ✅ **Complete MPU6050 driver** (init, read, I2C communication)
- ✅ **RMS calculation** for vibration analysis
- ✅ **Fault detection** with configurable thresholds
- ✅ **UART printf** support for debugging
- ✅ **LED alert indicators** (LD2 on PA5)
- ✅ **NanoEdge AI compatible** data format
- ✅ **100 Hz sampling** for accurate vibration capture

---

## 📸 Project Outputs

| Image | Description |
|-------|-------------|
| ![STM32CubeIDE](assets/stm32cubeide.png) | Project configuration in STM32CubeIDE |
| ![NanoEdge AI](assets/nanoedge.png) | AI model training in NanoEdge AI Studio |
| ![Regular Signals](assets/regular_signals.png) | Normal vibration pattern |
| ![Abnormal Signals](assets/abnormal_signals.png) | Fault vibration pattern |
| ![Benchmark](assets/benchmark.png) | AI model benchmark results |
| ![Serial Output](assets/serial_output.png) | Real-time serial monitor output |

---

## 🔮 Future Improvements

- [ ] Integrate NanoEdge AI library for on-device inference
- [ ] Add temperature sensor (DS18B20) for multi-parameter monitoring
- [ ] Add WiFi module (ESP8266) for cloud alerts
- [ ] Implement FFT for frequency-domain analysis
- [ ] Add OLED display for local status viewing
- [ ] Battery-powered portable design

---

## 📄 License

MIT License

---

## 👥 Team

- **Sandhiya S** — ECE, Government College of Engineering, Salem
- **Sherly T** — ECE, Government College of Engineering, Salem

**Guide:** [Professor Name]  
**College:** Government College of Engineering, Salem-11 (Anna University affiliated)
