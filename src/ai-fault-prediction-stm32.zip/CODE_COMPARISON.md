# CODE COMPARISON: Old vs New

## Your Original Code Issues (FIXED in new version)

### ❌ Issue 1: Missing MPU6050 Driver
**Your code:**
```c
#include "mpu.h"          // ← This file doesn't exist!
MPU6050_Init();           // ← Function declared but not defined
MPU6050_Read_Accel(accel_data);  // ← Function declared but not defined
Ax = ???;                 // ← Variables Ax, Ay, Az never declared
```

**Fixed in new code:**
```c
// Complete MPU6050 driver included in main.c:
uint8_t MPU6050_Init(void);           // Full initialization with WHO_AM_I check
void MPU6050_Read_Accel(float *accel); // Reads raw data, converts to g-force
HAL_StatusTypeDef MPU6050_Write(uint8_t reg, uint8_t data);
HAL_StatusTypeDef MPU6050_Read(uint8_t reg, uint8_t *data, uint16_t len);
```

---

### ❌ Issue 2: Undefined Variables
**Your code:**
```c
mpu_buffer[AXIS_NUMBER*i]=Ax;       // ← Ax not declared anywhere
mpu_buffer[AXIS_NUMBER*i+1]=Ay;     // ← Ay not declared anywhere
mpu_buffer[AXIS_NUMBER*i+2]=Az;     // ← Az not declared anywhere
MPU6050_Read_Accel(accel_data);       // ← accel_data not declared
```

**Fixed in new code:**
```c
float accel_data[3] = {0};  // Properly declared global array

void MPU6050_Read_Accel(float *accel) {
    // Reads into accel[0], accel[1], accel[2]
}

mpu_buffer[AXIS_NUMBER*i]     = accel_data[0];  // X-axis
mpu_buffer[AXIS_NUMBER*i + 1] = accel_data[1];  // Y-axis
mpu_buffer[AXIS_NUMBER*i + 2] = accel_data[2];  // Z-axis
```

---

### ❌ Issue 3: Missing Alert System
**Your code:**
```c
while (1) {
    Log();    // ← Only logs data, no fault detection
}
```

**Fixed in new code:**
```c
while (1) {
    fill_mpu_buffer();        // Collect 256 samples
    check_fault_condition();  // Calculate RMS, detect anomalies
    trigger_alert(level);     // LED + UART alert
    Log_Data();               // Print status
}
```

---

### ❌ Issue 4: No RMS Calculation
**Your code:** Raw data logged directly, no analysis

**Fixed in new code:**
```c
float calculate_rms(float *data, uint16_t len) {
    float sum = 0.0f;
    for (uint16_t i = 0; i < len; i++) {
        sum += (data[i] * data[i]);
    }
    return sqrtf(sum / len);  // Root Mean Square
}
```

---

### ❌ Issue 5: Bug in Buffer Index
**Your code:**
```c
printf("%.2f",mpu_buffer[AXIS_NUMBER *i]+2);  // ← +2 outside array!
// Should be: mpu_buffer[AXIS_NUMBER*i + 2]
```

**Fixed in new code:**
```c
printf("%.4f", mpu_buffer[AXIS_NUMBER * i + 2]);  // Correct indexing
```

---

### ❌ Issue 6: No Error Handling
**Your code:** No check if MPU6050 is connected

**Fixed in new code:**
```c
if (MPU6050_Init() != 0) {
    printf("ERROR: MPU6050 initialization failed!\r\n");
    Error_Handler();  // Blink LED rapidly
}
```

---

## What Was CORRECT in Your Original Code

| Feature | Your Code | Status |
|---------|-----------|--------|
| HAL initialization | ✅ Correct | Kept as-is |
| System clock config | ✅ Correct | Kept as-is |
| I2C1 initialization | ✅ Correct | Kept as-is |
| USART2 initialization | ✅ Correct | Kept as-is |
| GPIO initialization | ✅ Correct | Kept as-is |
| UART printf (`__io_putchar`) | ✅ Correct | Kept as-is |
| Buffer size (256×3) | ✅ Correct | Kept as-is |
| Sampling approach | ✅ Correct | Improved |

---

## New Features Added

| Feature | Description |
|---------|-------------|
| 🆕 Complete MPU6050 driver | Full I2C read/write with error checking |
| 🆕 WHO_AM_I verification | Confirms sensor is connected |
| 🆕 g-force conversion | Raw ADC → g-force (LSB=16384 for ±2g) |
| 🆕 RMS calculation | Vibration magnitude analysis |
| 🆕 Fault detection | 3-level alert system |
| 🆕 LED alerts | LD2 blinks for warning/critical |
| 🆕 Status logging | Formatted UART output |
| 🆕 NanoEdge AI format | CSV output for AI training |
| 🆕 Error handler | LED blink on fatal error |

---

## How to Use This Code

### For Data Collection (NanoEdge AI Training):
```c
// In main() while(1) loop, uncomment:
send_data_to_nanoedge();
```

### For Real-time Monitoring:
```c
// Default mode - shows status every 500ms:
fill_mpu_buffer();
check_fault_condition();
Log_Data();
```

---

## Pin Mapping (Nucleo-L476RG)

| Function | Pin | Description |
|----------|-----|-------------|
| I2C1_SCL | PB8 | MPU6050 SCL |
| I2C1_SDA | PB9 | MPU6050 SDA |
| USART2_TX | PA2 | USB Virtual COM TX |
| USART2_RX | PA3 | USB Virtual COM RX |
| LD2 (LED) | PA5 | Status indicator |
| B1 (Button) | PC13 | User button |
